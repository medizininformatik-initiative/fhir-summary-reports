# Patient Age and Gender Stratification Library - Testing - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient Age and Gender Stratification Library**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

*  [Narrative Content](Library-mii-lib-stratifier-age-gender.md) 
*  [XML](Library-mii-lib-stratifier-age-gender.xml.md) 
*  [JSON](Library-mii-lib-stratifier-age-gender.json.md) 
*  [TTL](Library-mii-lib-stratifier-age-gender.ttl.md) 

## Library: Patient Age and Gender Stratification Library - Testing 

| |
| :--- |
| Active as of 2025-09-30 |

### Test Plans

**No test plans are currently available for the Library.**

### Test Scripts

**No test scripts are currently available for the Library.**

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

