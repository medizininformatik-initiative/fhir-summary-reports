# Artifacts Summary - v0.1.0

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Terminology: Code Systems 

These define new code systems used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Summary Report Codes](CodeSystem-mii-cs-summary-report-codes.md) | Codes used in summary reports |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| | |
| :--- | :--- |
| [Patient Age and Gender Stratification Library](Library-mii-lib-stratifier-age-gender.md) | CQL library for calculating patient ages and gender-based stratifications |
| [Summary Report](Measure-mii-msr-summary-report-fhir-data-evaluator.md) | Summary Report that uses FHIRPath and works with the FHIR Data Evaluator |
| [Summary Report Age Gender CQL](Measure-mii-msr-summary-report-age-gender-cql.md) | Summary Report with gender and 5-year age group stratification using CQL matching German census data structure |
| [Summary Report Composite Age Gender CQL](Measure-mii-msr-summary-report-composite-gender-age-cql.md) | Summary Report with gender and age decade stratification using CQL in a composite stratifier |
| [mii-bdl-measure-library-transaction-bundle](Bundle-mii-bdl-measure-library-transaction-bundle.md) |  |
| [mii-msr-age-gender-separated-zensus-de-2011](MeasureReport-mii-msr-age-gender-separated-zensus-de-2011.md) |  |
| [mii-msr-age-gender-separated-zensus-de-2022](MeasureReport-mii-msr-age-gender-separated-zensus-de-2022.md) |  |
| [mii-msrpt-summary-report-zensus-2011](MeasureReport-mii-msrpt-summary-report-zensus-2011.md) |  |
| [mii-msrpt-summary-report-zensus-2022](MeasureReport-mii-msrpt-summary-report-zensus-2022.md) |  |

### Other 

These are resources that are used within this implementation guide that do not fit into one of the other categories.

| |
| :--- |
| [MeasureReport/MeasureReport-age-gender-composite](MeasureReport-MeasureReport-age-gender-composite.md) |
| [MeasureReport/MeasureReport-age-gender-separate](MeasureReport-MeasureReport-age-gender-separate.md) |

