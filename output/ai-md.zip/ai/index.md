# Home - v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

## Home

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/summary-reports/ImplementationGuide/summary-reports | *Version*:0.1.0 |
| Draft as of 2025-10-01 | *Computable Name*:SummaryReports |

# SummaryReports

Feel free to modify this index page with your own awesome content!

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

