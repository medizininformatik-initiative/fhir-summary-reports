# summary-reports#0.1.0: null

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [Summary Report Codes](CodeSystem-mii-cs-summary-report-codes.md)

### ImplementationGuides

* [SummaryReports](index.md)

### MeasureReports

* [MeasureReport-age-gender-composite](MeasureReport-MeasureReport-age-gender-composite.md)
* [MeasureReport-age-gender-separate](MeasureReport-MeasureReport-age-gender-separate.md)

### Examples

* [mii-bdl-measure-library-transaction-bundle (Bundle)](Bundle-mii-bdl-measure-library-transaction-bundle.md)
* [Patient Age and Gender Stratification Library (Library)](Library-mii-lib-stratifier-age-gender.md)
* [Summary Report Age Gender CQL (Measure)](Measure-mii-msr-summary-report-age-gender-cql.md)
* [Summary Report Composite Age Gender CQL (Measure)](Measure-mii-msr-summary-report-composite-gender-age-cql.md)
* [Summary Report (Measure)](Measure-mii-msr-summary-report-fhir-data-evaluator.md)
* [mii-msr-age-gender-separated-zensus-de-2011 (MeasureReport)](MeasureReport-mii-msr-age-gender-separated-zensus-de-2011.md)
* [mii-msr-age-gender-separated-zensus-de-2022 (MeasureReport)](MeasureReport-mii-msr-age-gender-separated-zensus-de-2022.md)
* [mii-msrpt-summary-report-zensus-2011 (MeasureReport)](MeasureReport-mii-msrpt-summary-report-zensus-2011.md)
* [mii-msrpt-summary-report-zensus-2022 (MeasureReport)](MeasureReport-mii-msrpt-summary-report-zensus-2022.md)
