# Summary Report Composite Age Gender CQL - Testing - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Summary Report Composite Age Gender CQL**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

*  [Narrative Content](Measure-mii-msr-summary-report-composite-gender-age-cql.md) 
*  [XML](Measure-mii-msr-summary-report-composite-gender-age-cql.xml.md) 
*  [JSON](Measure-mii-msr-summary-report-composite-gender-age-cql.json.md) 
*  [TTL](Measure-mii-msr-summary-report-composite-gender-age-cql.ttl.md) 

## Measure: Summary Report Composite Age Gender CQL - Testing 

| |
| :--- |
| Active as of 2025-09-30 |

### Test Plans

**No test plans are currently available for the Measure.**

### Test Scripts

**No test scripts are currently available for the Measure.**

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

