# Cross-version Extension for R5.MeasureReport.group.linkId for use in FHIR R4 - TTL Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Cross-version Extension for R5.MeasureReport.group.linkId for use in FHIR R4**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

*  [Content](StructureDefinition-ext-R5-MeasureReport.gr.linkId.md) 
*  [Detailed Descriptions](StructureDefinition-ext-R5-MeasureReport.gr.linkId-definitions.md) 
*  [Mappings](StructureDefinition-ext-R5-MeasureReport.gr.linkId-mappings.md) 
*  [XML](StructureDefinition-ext-R5-MeasureReport.gr.linkId.profile.xml.md) 
*  [JSON](StructureDefinition-ext-R5-MeasureReport.gr.linkId.profile.json.md) 
*  [TTL](#) 

## Extension: ext_R5_MeasureReport_gr_linkId - TTL Profile

| |
| :--- |
| *Page standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) |

TTL representation of the ext-R5-MeasureReport.gr.linkId extension.

[Raw ttl](StructureDefinition-ext-R5-MeasureReport.gr.linkId.ttl) | [Download](StructureDefinition-ext-R5-MeasureReport.gr.linkId.ttl)

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

