# Home - v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/summary-reports/ImplementationGuide/summary-reports | *Version*:0.1.0 |
| Draft as of 2025-10-28 | *Computable Name*:SummaryReports |

# SummaryReports

Feel free to modify this index page with your own awesome content!

