# Summary Report Codes - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Summary Report Codes**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-summary-report-codes.xml.md) 
*  [JSON](CodeSystem-summary-report-codes.json.md) 
*  [TTL](CodeSystem-summary-report-codes.ttl.md) 

## CodeSystem: Summary Report Codes 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/summary-reports/CodeSystem/summary-report-codes | *Version*:0.1.0 |
| Draft as of 2025-10-01 | *Computable Name*:SummaryReportCodes |

 
Codes used in summary reports 

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

This code system `https://www.medizininformatik-initiative.de/fhir/summary-reports/CodeSystem/summary-report-codes` defines the following codes:

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

