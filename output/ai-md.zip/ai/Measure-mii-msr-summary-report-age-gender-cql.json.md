# Summary Report Age Gender CQL - JSON Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Summary Report Age Gender CQL**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

*  [Narrative Content](Measure-mii-msr-summary-report-age-gender-cql.md) 
*  [XML](Measure-mii-msr-summary-report-age-gender-cql.xml.md) 
*  [JSON](#) 
*  [TTL](Measure-mii-msr-summary-report-age-gender-cql.ttl.md) 

## : Summary Report Age Gender CQL - JSON Representation

| |
| :--- |
| Active as of 2025-09-30 |

[Raw json](Measure-mii-msr-summary-report-age-gender-cql.json) | [Download](Measure-mii-msr-summary-report-age-gender-cql.json)

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

