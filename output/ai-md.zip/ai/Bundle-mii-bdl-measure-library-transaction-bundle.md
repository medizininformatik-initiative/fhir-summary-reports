# mii-bdl-measure-library-transaction-bundle - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-bdl-measure-library-transaction-bundle**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

*  [Narrative Content](#) 
*  [XML](Bundle-mii-bdl-measure-library-transaction-bundle.xml.md) 
*  [JSON](Bundle-mii-bdl-measure-library-transaction-bundle.json.md) 
*  [TTL](Bundle-mii-bdl-measure-library-transaction-bundle.ttl.md) 

## Example Bundle: mii-bdl-measure-library-transaction-bundle

Bundle mii-bdl-measure-library-transaction-bundle of type transaction

-------

Entry 1 - fullUrl = https://www.medizininformatik-initiative.de/Library/mii-lib-stratifier-age-gender

Resource Library:

> 

* * **Content:**text/cql: ````library "stratifier-age-gender" using FHIR version '4.0.0' include FHIRHelpers version '4.0.0' context Patient define InInitialPopulation: true define BirthYear: year from Patient.birthDate // Calculate the patient's age in years as of today define AgeInYears: AgeInYearsAt(Today()) // Calculate the patient's age in years at a specific date define function AgeInYearsAt(asOf DateTime): if Patient.birthDate is null then null else years between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Calculate the patient's age in months define AgeInMonths: AgeInMonthsAt(Today()) // Calculate the patient's age in months at a specific date define function AgeInMonthsAt(asOf DateTime): if Patient.birthDate is null then null else months between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Calculate the patient's age in days define AgeInDays: AgeInDaysAt(Today()) // Calculate the patient's age in days at a specific date define function AgeInDaysAt(asOf DateTime): if Patient.birthDate is null then null else days between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Alternative age calculation using date arithmetic define AgeInYearsSimple: if Patient.birthDate is null then null else year from Today() - year from FHIRHelpers.ToDate(Patient.birthDate) // Age stratification examples define AgeGroup: case when AgeInYears is null then null when AgeInYears < 18 then 'Pediatric' when AgeInYears >= 18 and AgeInYears < 65 then 'Adult' when AgeInYears >= 65 then 'Geriatric' else null end define AgeDecade: case when AgeInYears is null then null when AgeInYears < 10 then '0-9' when AgeInYears >= 10 and AgeInYears < 20 then '10-19' when AgeInYears >= 20 and AgeInYears < 30 then '20-29' when AgeInYears >= 30 and AgeInYears < 40 then '30-39' when AgeInYears >= 40 and AgeInYears < 50 then '40-49' when AgeInYears >= 50 and AgeInYears < 60 then '50-59' when AgeInYears >= 60 and AgeInYears < 70 then '60-69' when AgeInYears >= 70 and AgeInYears < 80 then '70-79' when AgeInYears >= 80 and AgeInYears < 90 then '80-89' when AgeInYears >= 90 then '90+' else null end // Check if patient is an adult (18 or older) define IsAdult: AgeInYears >= 18 // Check if patient is a minor (under 18) define IsMinor: AgeInYears < 18 // Check if patient is elderly (65 or older) define IsElderly: AgeInYears >= 65 // Gender for stratification define Gender: Patient.gender````: **Id:**
  * ?: mii-lib-stratifier-age-gender
* * **Content:**text/cql: ````library "stratifier-age-gender" using FHIR version '4.0.0' include FHIRHelpers version '4.0.0' context Patient define InInitialPopulation: true define BirthYear: year from Patient.birthDate // Calculate the patient's age in years as of today define AgeInYears: AgeInYearsAt(Today()) // Calculate the patient's age in years at a specific date define function AgeInYearsAt(asOf DateTime): if Patient.birthDate is null then null else years between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Calculate the patient's age in months define AgeInMonths: AgeInMonthsAt(Today()) // Calculate the patient's age in months at a specific date define function AgeInMonthsAt(asOf DateTime): if Patient.birthDate is null then null else months between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Calculate the patient's age in days define AgeInDays: AgeInDaysAt(Today()) // Calculate the patient's age in days at a specific date define function AgeInDaysAt(asOf DateTime): if Patient.birthDate is null then null else days between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Alternative age calculation using date arithmetic define AgeInYearsSimple: if Patient.birthDate is null then null else year from Today() - year from FHIRHelpers.ToDate(Patient.birthDate) // Age stratification examples define AgeGroup: case when AgeInYears is null then null when AgeInYears < 18 then 'Pediatric' when AgeInYears >= 18 and AgeInYears < 65 then 'Adult' when AgeInYears >= 65 then 'Geriatric' else null end define AgeDecade: case when AgeInYears is null then null when AgeInYears < 10 then '0-9' when AgeInYears >= 10 and AgeInYears < 20 then '10-19' when AgeInYears >= 20 and AgeInYears < 30 then '20-29' when AgeInYears >= 30 and AgeInYears < 40 then '30-39' when AgeInYears >= 40 and AgeInYears < 50 then '40-49' when AgeInYears >= 50 and AgeInYears < 60 then '50-59' when AgeInYears >= 60 and AgeInYears < 70 then '60-69' when AgeInYears >= 70 and AgeInYears < 80 then '70-79' when AgeInYears >= 80 and AgeInYears < 90 then '80-89' when AgeInYears >= 90 then '90+' else null end // Check if patient is an adult (18 or older) define IsAdult: AgeInYears >= 18 // Check if patient is a minor (under 18) define IsMinor: AgeInYears < 18 // Check if patient is elderly (65 or older) define IsElderly: AgeInYears >= 65 // Gender for stratification define Gender: Patient.gender````: **Version:**
  * ?: 1.0.0
* * **Content:**text/cql: ````library "stratifier-age-gender" using FHIR version '4.0.0' include FHIRHelpers version '4.0.0' context Patient define InInitialPopulation: true define BirthYear: year from Patient.birthDate // Calculate the patient's age in years as of today define AgeInYears: AgeInYearsAt(Today()) // Calculate the patient's age in years at a specific date define function AgeInYearsAt(asOf DateTime): if Patient.birthDate is null then null else years between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Calculate the patient's age in months define AgeInMonths: AgeInMonthsAt(Today()) // Calculate the patient's age in months at a specific date define function AgeInMonthsAt(asOf DateTime): if Patient.birthDate is null then null else months between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Calculate the patient's age in days define AgeInDays: AgeInDaysAt(Today()) // Calculate the patient's age in days at a specific date define function AgeInDaysAt(asOf DateTime): if Patient.birthDate is null then null else days between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Alternative age calculation using date arithmetic define AgeInYearsSimple: if Patient.birthDate is null then null else year from Today() - year from FHIRHelpers.ToDate(Patient.birthDate) // Age stratification examples define AgeGroup: case when AgeInYears is null then null when AgeInYears < 18 then 'Pediatric' when AgeInYears >= 18 and AgeInYears < 65 then 'Adult' when AgeInYears >= 65 then 'Geriatric' else null end define AgeDecade: case when AgeInYears is null then null when AgeInYears < 10 then '0-9' when AgeInYears >= 10 and AgeInYears < 20 then '10-19' when AgeInYears >= 20 and AgeInYears < 30 then '20-29' when AgeInYears >= 30 and AgeInYears < 40 then '30-39' when AgeInYears >= 40 and AgeInYears < 50 then '40-49' when AgeInYears >= 50 and AgeInYears < 60 then '50-59' when AgeInYears >= 60 and AgeInYears < 70 then '60-69' when AgeInYears >= 70 and AgeInYears < 80 then '70-79' when AgeInYears >= 80 and AgeInYears < 90 then '80-89' when AgeInYears >= 90 then '90+' else null end // Check if patient is an adult (18 or older) define IsAdult: AgeInYears >= 18 // Check if patient is a minor (under 18) define IsMinor: AgeInYears < 18 // Check if patient is elderly (65 or older) define IsElderly: AgeInYears >= 65 // Gender for stratification define Gender: Patient.gender````: **Url:**
  * ?: [Patient Age and Gender Stratification Library](Library-mii-lib-stratifier-age-gender.md)
* * **Content:**text/cql: ````library "stratifier-age-gender" using FHIR version '4.0.0' include FHIRHelpers version '4.0.0' context Patient define InInitialPopulation: true define BirthYear: year from Patient.birthDate // Calculate the patient's age in years as of today define AgeInYears: AgeInYearsAt(Today()) // Calculate the patient's age in years at a specific date define function AgeInYearsAt(asOf DateTime): if Patient.birthDate is null then null else years between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Calculate the patient's age in months define AgeInMonths: AgeInMonthsAt(Today()) // Calculate the patient's age in months at a specific date define function AgeInMonthsAt(asOf DateTime): if Patient.birthDate is null then null else months between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Calculate the patient's age in days define AgeInDays: AgeInDaysAt(Today()) // Calculate the patient's age in days at a specific date define function AgeInDaysAt(asOf DateTime): if Patient.birthDate is null then null else days between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Alternative age calculation using date arithmetic define AgeInYearsSimple: if Patient.birthDate is null then null else year from Today() - year from FHIRHelpers.ToDate(Patient.birthDate) // Age stratification examples define AgeGroup: case when AgeInYears is null then null when AgeInYears < 18 then 'Pediatric' when AgeInYears >= 18 and AgeInYears < 65 then 'Adult' when AgeInYears >= 65 then 'Geriatric' else null end define AgeDecade: case when AgeInYears is null then null when AgeInYears < 10 then '0-9' when AgeInYears >= 10 and AgeInYears < 20 then '10-19' when AgeInYears >= 20 and AgeInYears < 30 then '20-29' when AgeInYears >= 30 and AgeInYears < 40 then '30-39' when AgeInYears >= 40 and AgeInYears < 50 then '40-49' when AgeInYears >= 50 and AgeInYears < 60 then '50-59' when AgeInYears >= 60 and AgeInYears < 70 then '60-69' when AgeInYears >= 70 and AgeInYears < 80 then '70-79' when AgeInYears >= 80 and AgeInYears < 90 then '80-89' when AgeInYears >= 90 then '90+' else null end // Check if patient is an adult (18 or older) define IsAdult: AgeInYears >= 18 // Check if patient is a minor (under 18) define IsMinor: AgeInYears < 18 // Check if patient is elderly (65 or older) define IsElderly: AgeInYears >= 65 // Gender for stratification define Gender: Patient.gender````: **Date:**
  * ?: 2025-09-30
* * **Content:**text/cql: ````library "stratifier-age-gender" using FHIR version '4.0.0' include FHIRHelpers version '4.0.0' context Patient define InInitialPopulation: true define BirthYear: year from Patient.birthDate // Calculate the patient's age in years as of today define AgeInYears: AgeInYearsAt(Today()) // Calculate the patient's age in years at a specific date define function AgeInYearsAt(asOf DateTime): if Patient.birthDate is null then null else years between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Calculate the patient's age in months define AgeInMonths: AgeInMonthsAt(Today()) // Calculate the patient's age in months at a specific date define function AgeInMonthsAt(asOf DateTime): if Patient.birthDate is null then null else months between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Calculate the patient's age in days define AgeInDays: AgeInDaysAt(Today()) // Calculate the patient's age in days at a specific date define function AgeInDaysAt(asOf DateTime): if Patient.birthDate is null then null else days between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Alternative age calculation using date arithmetic define AgeInYearsSimple: if Patient.birthDate is null then null else year from Today() - year from FHIRHelpers.ToDate(Patient.birthDate) // Age stratification examples define AgeGroup: case when AgeInYears is null then null when AgeInYears < 18 then 'Pediatric' when AgeInYears >= 18 and AgeInYears < 65 then 'Adult' when AgeInYears >= 65 then 'Geriatric' else null end define AgeDecade: case when AgeInYears is null then null when AgeInYears < 10 then '0-9' when AgeInYears >= 10 and AgeInYears < 20 then '10-19' when AgeInYears >= 20 and AgeInYears < 30 then '20-29' when AgeInYears >= 30 and AgeInYears < 40 then '30-39' when AgeInYears >= 40 and AgeInYears < 50 then '40-49' when AgeInYears >= 50 and AgeInYears < 60 then '50-59' when AgeInYears >= 60 and AgeInYears < 70 then '60-69' when AgeInYears >= 70 and AgeInYears < 80 then '70-79' when AgeInYears >= 80 and AgeInYears < 90 then '80-89' when AgeInYears >= 90 then '90+' else null end // Check if patient is an adult (18 or older) define IsAdult: AgeInYears >= 18 // Check if patient is a minor (under 18) define IsMinor: AgeInYears < 18 // Check if patient is elderly (65 or older) define IsElderly: AgeInYears >= 65 // Gender for stratification define Gender: Patient.gender````: **Publisher:**
  * ?: MII
* * **Content:**text/cql: ````library "stratifier-age-gender" using FHIR version '4.0.0' include FHIRHelpers version '4.0.0' context Patient define InInitialPopulation: true define BirthYear: year from Patient.birthDate // Calculate the patient's age in years as of today define AgeInYears: AgeInYearsAt(Today()) // Calculate the patient's age in years at a specific date define function AgeInYearsAt(asOf DateTime): if Patient.birthDate is null then null else years between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Calculate the patient's age in months define AgeInMonths: AgeInMonthsAt(Today()) // Calculate the patient's age in months at a specific date define function AgeInMonthsAt(asOf DateTime): if Patient.birthDate is null then null else months between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Calculate the patient's age in days define AgeInDays: AgeInDaysAt(Today()) // Calculate the patient's age in days at a specific date define function AgeInDaysAt(asOf DateTime): if Patient.birthDate is null then null else days between FHIRHelpers.ToDate(Patient.birthDate) and asOf // Alternative age calculation using date arithmetic define AgeInYearsSimple: if Patient.birthDate is null then null else year from Today() - year from FHIRHelpers.ToDate(Patient.birthDate) // Age stratification examples define AgeGroup: case when AgeInYears is null then null when AgeInYears < 18 then 'Pediatric' when AgeInYears >= 18 and AgeInYears < 65 then 'Adult' when AgeInYears >= 65 then 'Geriatric' else null end define AgeDecade: case when AgeInYears is null then null when AgeInYears < 10 then '0-9' when AgeInYears >= 10 and AgeInYears < 20 then '10-19' when AgeInYears >= 20 and AgeInYears < 30 then '20-29' when AgeInYears >= 30 and AgeInYears < 40 then '30-39' when AgeInYears >= 40 and AgeInYears < 50 then '40-49' when AgeInYears >= 50 and AgeInYears < 60 then '50-59' when AgeInYears >= 60 and AgeInYears < 70 then '60-69' when AgeInYears >= 70 and AgeInYears < 80 then '70-79' when AgeInYears >= 80 and AgeInYears < 90 then '80-89' when AgeInYears >= 90 then '90+' else null end // Check if patient is an adult (18 or older) define IsAdult: AgeInYears >= 18 // Check if patient is a minor (under 18) define IsMinor: AgeInYears < 18 // Check if patient is elderly (65 or older) define IsElderly: AgeInYears >= 65 // Gender for stratification define Gender: Patient.gender````: **Description:**
  * ?: CQL library for calculating patient ages and gender-based stratifications


Request:

```
PUT Library/mii-lib-stratifier-age-gender

```

-------

Entry 2 - fullUrl = https://www.medizininformatik-initiative.de/Measure/mii-msr-summary-report-age-gender-cql

Resource Measure:

> 

* Knowledge Artifact Metadata: Name (machine-readable)
  * ?: SummaryReportAgeGenderCQL
* Knowledge Artifact Metadata: Title (human-readable)
  * ?: Summary Report Age Gender CQL
* Knowledge Artifact Metadata: Status
  * ?: Active
* Knowledge Artifact Metadata: Experimental
  * ?: false
* Knowledge Artifact Metadata: Description
  * ?: Summary Report with gender and age decade stratification using CQL
* Knowledge Artifact Metadata: Measure Steward
  * ?: MII
* Knowledge Artifact Metadata: Measure Metadata
* Knowledge Artifact Metadata: Version Number
  * ?: 1.0
* Knowledge Artifact Metadata: Measure Population Criteria
* Knowledge Artifact Metadata: Summary
  * ?: Patient stratification by gender and age decade
* Knowledge Artifact Metadata: Initial Population
  * ?: **ID**: initial-population-identifier**Description**: No description provided**Logic Definition**:[InInitialPopulation](#stratifieragegender-ininitialpopulation)
* Knowledge Artifact Metadata: Stratifier
  * ?: **ID**: strat-gender**Code**:gender
* Knowledge Artifact Metadata: Stratifier
  * ?: **ID**: strat-age-decade**Code**:age-decade
* Knowledge Artifact Metadata: Measure Logic
* Knowledge Artifact Metadata: Primary Library
  * ?: [Patient Age and Gender Stratification Library](Bundle-mii-bdl-measure-library-transaction-bundle.md)
* Knowledge Artifact Metadata: Generated using version 0.4.6 of the sample-content-ig Liquid templates


Request:

```
PUT Measure/mii-msr-summary-report-age-gender-cql

```

-------

Entry 3 - fullUrl = https://www.medizininformatik-initiative.de/Measure/mii-msr-summary-report-composite-gender-age-cql

Resource Measure:

> 

* Knowledge Artifact Metadata: Name (machine-readable)
  * ?: SummaryReportCompositeAgeGenderCQL
* Knowledge Artifact Metadata: Title (human-readable)
  * ?: Summary Report Composite Age Gender CQL
* Knowledge Artifact Metadata: Status
  * ?: Active
* Knowledge Artifact Metadata: Experimental
  * ?: false
* Knowledge Artifact Metadata: Description
  * ?: Summary Report with gender and age decade stratification using CQL in a composite stratifier
* Knowledge Artifact Metadata: Measure Steward
  * ?: MII
* Knowledge Artifact Metadata: Measure Metadata
* Knowledge Artifact Metadata: Version Number
  * ?: 1.0
* Knowledge Artifact Metadata: Measure Population Criteria
* Knowledge Artifact Metadata: Summary
  * ?: Composite stratification by gender and age decade
* Knowledge Artifact Metadata: Initial Population
  * ?: **ID**: initial-population**Description**: No description provided**Logic Definition**:[InInitialPopulation](#stratifieragegender-ininitialpopulation)
* Knowledge Artifact Metadata: Stratifier
  * ?: **ID**: strat-gender-age**Code**:gender-age-composite**Description**:Combined gender and age decade stratification
* Knowledge Artifact Metadata: Measure Logic
* Knowledge Artifact Metadata: Primary Library
  * ?: [Patient Age and Gender Stratification Library](Bundle-mii-bdl-measure-library-transaction-bundle.md)
* Knowledge Artifact Metadata: Generated using version 0.4.6 of the sample-content-ig Liquid templates


Request:

```
PUT Measure/mii-msr-summary-report-composite-gender-age-cql

```

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

