# mii-bdl-measure-library-transaction-bundle - JSON Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-bdl-measure-library-transaction-bundle**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

*  [Narrative Content](Bundle-mii-bdl-measure-library-transaction-bundle.md) 
*  [XML](Bundle-mii-bdl-measure-library-transaction-bundle.xml.md) 
*  [JSON](#) 
*  [TTL](Bundle-mii-bdl-measure-library-transaction-bundle.ttl.md) 

## : mii-bdl-measure-library-transaction-bundle - JSON Representation

[Raw json](Bundle-mii-bdl-measure-library-transaction-bundle.json) | [Download](Bundle-mii-bdl-measure-library-transaction-bundle.json)

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

