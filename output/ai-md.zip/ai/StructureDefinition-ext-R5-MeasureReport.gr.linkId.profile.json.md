# Cross-version Extension for R5.MeasureReport.group.linkId for use in FHIR R4 - JSON Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Cross-version Extension for R5.MeasureReport.group.linkId for use in FHIR R4**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

*  [Content](StructureDefinition-ext-R5-MeasureReport.gr.linkId.md) 
*  [Detailed Descriptions](StructureDefinition-ext-R5-MeasureReport.gr.linkId-definitions.md) 
*  [Mappings](StructureDefinition-ext-R5-MeasureReport.gr.linkId-mappings.md) 
*  [XML](StructureDefinition-ext-R5-MeasureReport.gr.linkId.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-ext-R5-MeasureReport.gr.linkId.profile.ttl.md) 

## Extension: ext_R5_MeasureReport_gr_linkId - JSON Profile

| |
| :--- |
| *Page standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) |

JSON representation of the ext-R5-MeasureReport.gr.linkId extension.

[Raw json](StructureDefinition-ext-R5-MeasureReport.gr.linkId.json) | [Download](StructureDefinition-ext-R5-MeasureReport.gr.linkId.json)

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

