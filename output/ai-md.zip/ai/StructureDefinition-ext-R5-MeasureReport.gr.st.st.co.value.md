# Cross-version Extension for R5.MeasureReport.group.stratifier.stratum.component.value[x] for use in FHIR R4 - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Cross-version Extension for R5.MeasureReport.group.stratifier.stratum.component.value[x] for use in FHIR R4**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ext-R5-MeasureReport.gr.st.st.co.value-definitions.md) 
*  [Mappings](StructureDefinition-ext-R5-MeasureReport.gr.st.st.co.value-mappings.md) 
*  [XML](StructureDefinition-ext-R5-MeasureReport.gr.st.st.co.value.profile.xml.md) 
*  [JSON](StructureDefinition-ext-R5-MeasureReport.gr.st.st.co.value.profile.json.md) 
*  [TTL](StructureDefinition-ext-R5-MeasureReport.gr.st.st.co.value.profile.ttl.md) 

## Extension: Cross-version Extension for R5.MeasureReport.group.stratifier.stratum.component.value[x] for use in FHIR R4 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org/fhir/5.0/StructureDefinition/extension-MeasureReport.group.stratifier.stratum.component.value | *Version*:0.1.0 |
| *Standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | *Computable Name*:ext_R5_MeasureReport_gr_st_st_co_value |

| | |
| :--- | :--- |
| This cross-version extension represents MeasureReport.group.stratifier.stratum.component.value[x] from http://hl7.org/fhir/StructureDefinition/MeasureReport | 5.0.0 for use in FHIR R4. |

**Context of Use**

**Usage info**

**Usages:**

* This Extension is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/summary-reports|current/StructureDefinition/ext-R5-MeasureReport.gr.st.st.co.value)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type boolean, CodeableConcept, Quantity, Range, Reference: This cross-version extension represents MeasureReport.group.stratifier.stratum.component.value[x] from http://hl7.org/fhir/StructureDefinition/MeasureReport|5.0.0 for use in FHIR R4.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type boolean, CodeableConcept, Quantity, Range, Reference: This cross-version extension represents MeasureReport.group.stratifier.stratum.component.value[x] from http://hl7.org/fhir/StructureDefinition/MeasureReport|5.0.0 for use in FHIR R4.

 

Other representations of profile: [CSV](StructureDefinition-ext-R5-MeasureReport.gr.st.st.co.value.csv), [Excel](StructureDefinition-ext-R5-MeasureReport.gr.st.st.co.value.xlsx), [Schematron](StructureDefinition-ext-R5-MeasureReport.gr.st.st.co.value.sch) 

#### Terminology Bindings

#### Constraints

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

