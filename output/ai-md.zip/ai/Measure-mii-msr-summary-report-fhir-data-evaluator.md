# Summary Report - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Summary Report**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

*  [Narrative Content](#) 
*  [XML](Measure-mii-msr-summary-report-fhir-data-evaluator.xml.md) 
*  [JSON](Measure-mii-msr-summary-report-fhir-data-evaluator.json.md) 
*  [TTL](Measure-mii-msr-summary-report-fhir-data-evaluator.ttl.md) 

## Measure: Summary Report 

| | |
| :--- | :--- |
| *Official URL*:https://medizininformatik-initiative.de/fhir/Measure/SummaryReport | *Version*:0.1.0 |
| Active as of 2025-09-30 | *Computable Name*:SummaryReport |

 
Summary Report that uses FHIRPath and works with the FHIR Data Evaluator 

* Knowledge Artifact Metadata: Name (machine-readable)
  * ?: SummaryReport
* Knowledge Artifact Metadata: Title (human-readable)
  * ?: Summary Report
* Knowledge Artifact Metadata: Status
  * ?: Active
* Knowledge Artifact Metadata: Experimental
  * ?: false
* Knowledge Artifact Metadata: Description
  * ?: Summary Report that uses FHIRPath and works with the FHIR Data Evaluator
* Knowledge Artifact Metadata: Measure Steward
  * ?: Medizininformatik Initiative
* Knowledge Artifact Metadata: Steward Contact Details
  * ?: Medizininformatik Initiative:[https://www.medizininformatik-initiative.de/](https://www.medizininformatik-initiative.de/)
* Knowledge Artifact Metadata: Measure Metadata
* Knowledge Artifact Metadata: Version Number
  * ?: 0.1.0
* Knowledge Artifact Metadata: Measure Population Criteria
* Knowledge Artifact Metadata: Summary
  * ?: Simple Stratifier concept
* Knowledge Artifact Metadata: Initial Population
  * ?: **ID**: initial-population-identifier**Description**: No description provided
* Knowledge Artifact Metadata: Stratifier
  * ?: **ID**: strat-1**Code**:gender
* Knowledge Artifact Metadata: Generated using version 0.4.6 of the sample-content-ig Liquid templates

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

