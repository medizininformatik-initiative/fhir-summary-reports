# Summary Report - XML Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Summary Report**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

*  [Narrative Content](Measure-mii-msr-summary-report-fhir-data-evaluator.md) 
*  [XML](#) 
*  [JSON](Measure-mii-msr-summary-report-fhir-data-evaluator.json.md) 
*  [TTL](Measure-mii-msr-summary-report-fhir-data-evaluator.ttl.md) 

## : Summary Report - XML Representation

| |
| :--- |
| Active as of 2025-09-30 |

[Raw xml](Measure-mii-msr-summary-report-fhir-data-evaluator.xml) | [Download](Measure-mii-msr-summary-report-fhir-data-evaluator.xml)

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

