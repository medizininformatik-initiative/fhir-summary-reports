# Cross-version Extension for R5.MeasureReport.group.linkId for use in FHIR R4 - Testing - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Cross-version Extension for R5.MeasureReport.group.linkId for use in FHIR R4**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

*  [Content](StructureDefinition-ext-R5-MeasureReport.gr.linkId.md) 
*  [Detailed Descriptions](StructureDefinition-ext-R5-MeasureReport.gr.linkId-definitions.md) 
*  [Mappings](StructureDefinition-ext-R5-MeasureReport.gr.linkId-mappings.md) 
*  [XML](StructureDefinition-ext-R5-MeasureReport.gr.linkId.profile.xml.md) 
*  [JSON](StructureDefinition-ext-R5-MeasureReport.gr.linkId.profile.json.md) 
*  [TTL](StructureDefinition-ext-R5-MeasureReport.gr.linkId.profile.ttl.md) 

## Extension: ext_R5_MeasureReport_gr_linkId - Testing

| |
| :--- |
| *Page standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

