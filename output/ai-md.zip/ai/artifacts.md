# Artifacts Summary - v0.1.0

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

## Artifacts Summary

Contents:

*  [Structures: Extension Definitions](#1) 
*  [Terminology: Code Systems](#2) 
*  [Example: Example Instances](#3) 

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Structures: Extension Definitions 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Cross-version Extension for R5.MeasureReport.group.linkId for use in FHIR R4](StructureDefinition-ext-R5-MeasureReport.gr.linkId.md) | 
| | |
| :--- | :--- |
| This cross-version extension represents MeasureReport.group.linkId from http://hl7.org/fhir/StructureDefinition/MeasureReport | 5.0.0 for use in FHIR R4. |
 |
| [Cross-version Extension for R5.MeasureReport.group.population.linkId for use in FHIR R4](StructureDefinition-ext-R5-MeasureReport.gr.po.linkId.md) | 
| | |
| :--- | :--- |
| This cross-version extension represents MeasureReport.group.population.linkId from http://hl7.org/fhir/StructureDefinition/MeasureReport | 5.0.0 for use in FHIR R4. |
 |
| [Cross-version Extension for R5.MeasureReport.group.stratifier.linkId for use in FHIR R4](StructureDefinition-ext-R5-MeasureReport.gr.st.linkId.md) | 
| | |
| :--- | :--- |
| This cross-version extension represents MeasureReport.group.stratifier.linkId from http://hl7.org/fhir/StructureDefinition/MeasureReport | 5.0.0 for use in FHIR R4. |
 |
| [Cross-version Extension for R5.MeasureReport.group.stratifier.stratum.component.value[x] for use in FHIR R4](StructureDefinition-ext-R5-MeasureReport.gr.st.st.co.value.md) | 
| | |
| :--- | :--- |
| This cross-version extension represents MeasureReport.group.stratifier.stratum.component.value[x] from http://hl7.org/fhir/StructureDefinition/MeasureReport | 5.0.0 for use in FHIR R4. |
 |
| [Cross-version Extension for R5.MeasureReport.group.stratifier.stratum.value[x] for use in FHIR R4](StructureDefinition-ext-R5-MeasureReport.gr.st.st.value.md) | 
| | |
| :--- | :--- |
| This cross-version extension represents MeasureReport.group.stratifier.stratum.value[x] from http://hl7.org/fhir/StructureDefinition/MeasureReport | 5.0.0 for use in FHIR R4. |
 |

### Terminology: Code Systems 

These define new code systems used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Summary Report Codes](CodeSystem-summary-report-codes.md) | Codes used in summary reports |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| | |
| :--- | :--- |
| [Patient Age and Gender Stratification Library](Library-mii-lib-stratifier-age-gender.md) | CQL library for calculating patient ages and gender-based stratifications |
| [Summary Report](Measure-mii-msr-summary-report-fhir-data-evaluator.md) | Summary Report that uses FHIRPath and works with the FHIR Data Evaluator |
| [Summary Report Age Gender CQL](Measure-mii-msr-summary-report-age-gender-cql.md) | Summary Report with gender and age decade stratification using CQL |
| [Summary Report Composite Age Gender CQL](Measure-mii-msr-summary-report-composite-gender-age-cql.md) | Summary Report with gender and age decade stratification using CQL in a composite stratifier |
| [mii-bdl-measure-library-transaction-bundle](Bundle-mii-bdl-measure-library-transaction-bundle.md) |  |

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

