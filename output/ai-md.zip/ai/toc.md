# Table of Contents - v0.1.0

* **Table of Contents**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

## Table of Contents

| |
| :--- |
| [0 Table of Contents](toc.md) |
| [1 Home](index.md) |
| [2 Artifacts Summary](artifacts.md) |
| [2.1 Cross-version Extension for R5.MeasureReport.group.linkId for use in FHIR R4](StructureDefinition-ext-R5-MeasureReport.gr.linkId.md) |
| [2.2 Cross-version Extension for R5.MeasureReport.group.population.linkId for use in FHIR R4](StructureDefinition-ext-R5-MeasureReport.gr.po.linkId.md) |
| [2.3 Cross-version Extension for R5.MeasureReport.group.stratifier.linkId for use in FHIR R4](StructureDefinition-ext-R5-MeasureReport.gr.st.linkId.md) |
| [2.4 Cross-version Extension for R5.MeasureReport.group.stratifier.stratum.component.value[x] for use in FHIR R4](StructureDefinition-ext-R5-MeasureReport.gr.st.st.co.value.md) |
| [2.5 Cross-version Extension for R5.MeasureReport.group.stratifier.stratum.value[x] for use in FHIR R4](StructureDefinition-ext-R5-MeasureReport.gr.st.st.value.md) |
| [2.6 Summary Report Codes](CodeSystem-summary-report-codes.md) |
| [2.7 mii-bdl-measure-library-transaction-bundle](Bundle-mii-bdl-measure-library-transaction-bundle.md) |
| [2.8 Patient Age and Gender Stratification Library](Library-mii-lib-stratifier-age-gender.md) |
| [2.9 Summary Report](Measure-mii-msr-summary-report-fhir-data-evaluator.md) |
| [2.10 Summary Report Age Gender CQL](Measure-mii-msr-summary-report-age-gender-cql.md) |
| [2.11 Summary Report Composite Age Gender CQL](Measure-mii-msr-summary-report-composite-gender-age-cql.md) |

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

