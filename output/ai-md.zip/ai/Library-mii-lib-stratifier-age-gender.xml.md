# Patient Age and Gender Stratification Library - XML Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient Age and Gender Stratification Library**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

*  [Narrative Content](Library-mii-lib-stratifier-age-gender.md) 
*  [XML](#) 
*  [JSON](Library-mii-lib-stratifier-age-gender.json.md) 
*  [TTL](Library-mii-lib-stratifier-age-gender.ttl.md) 

## : Patient Age and Gender Stratification Library - XML Representation

| |
| :--- |
| Active as of 2025-09-30 |

[Raw xml](Library-mii-lib-stratifier-age-gender.xml) | [Download](Library-mii-lib-stratifier-age-gender.xml)

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

