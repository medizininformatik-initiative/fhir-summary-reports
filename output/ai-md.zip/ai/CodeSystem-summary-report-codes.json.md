# Summary Report Codes - JSON Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Summary Report Codes**

SummaryReports - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://www.medizininformatik-initiative.de/fhir/summary-reports/history.html)

*  [Narrative Content](CodeSystem-summary-report-codes.md) 
*  [XML](CodeSystem-summary-report-codes.xml.md) 
*  [JSON](#) 
*  [TTL](CodeSystem-summary-report-codes.ttl.md) 

## : Summary Report Codes - JSON Representation

| |
| :--- |
| Draft as of 2025-10-01 |

[Raw json](CodeSystem-summary-report-codes.json) | [Download](CodeSystem-summary-report-codes.json)

 IG © 2025+ [Medizininformatik Initiative](https://www.medizininformatik-initiative.de/). Package summary-reports#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-01 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

